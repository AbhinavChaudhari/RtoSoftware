from django.apps import AppConfig


class RtomodConfig(AppConfig):
    name = 'RTOMod'
